package wipro.assignments2;
import java.util.Scanner;
public class Matrix {
    private int[][] matrix;
    public Matrix(int rows, int cols) {
        matrix = new int[rows][cols];
    }
    public void MatrixValues(int[][] values) {
        if (values.length != matrix.length || values[0].length != matrix[0].length) {
            System.out.println("Error: Input values dimensions do not match matrix dimensions.");
            return;
        }

        for (int rows = 0; rows < matrix.length; rows++) {
            for (int cols = 0; cols < matrix[0].length; cols++) {
                matrix[rows][cols] = values[rows][cols];
            }
        }
    }
    public void MatrixDisplay() {
        for (int rows = 0; rows < matrix.length; rows++) {
            for (int cols = 0; cols < matrix[0].length; cols++) {
                System.out.print(matrix[rows][cols] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
    	System.out.println("Enter the number of rows : ");
    	int rows = scan.nextInt();
    	System.out.println("Enter the number of cols : ");
    	int cols = scan.nextInt();
    	int values[][] = new int[rows][cols];
    	System.out.println("Enter the elements in the 2D array : ");
    	for(int i =0;i< values.length;i++) {
    		for(int j=0;j<values[i].length;j++) {
    			values[i][j] = scan.nextInt();
    		}
    	}
    	Matrix ob = new Matrix(rows,cols);
        ob.MatrixValues(values);
        System.out.println("Matrix:");
        ob.MatrixDisplay();
    	scan.close();
    }
}
