package wipro.assignments2;
import java.util.Scanner;
public class Task2 {
    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
    	int radius = scan.nextInt();
        Circle circle = new Circle(radius);
        System.out.println("Area of Circle : " + circle.area());
        int length = scan.nextInt();
        int breath = scan.nextInt();
        Rectangle rectangle = new Rectangle(length, breath);
        System.out.println("Area of Rectangle : " + rectangle.area());
        Shape shape = new Shape();
        System.out.println("Area of Shape : "+ shape.area());
        scan.close();
    }
}
