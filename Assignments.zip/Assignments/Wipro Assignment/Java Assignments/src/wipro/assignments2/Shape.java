package wipro.assignments2;
public class Shape {
		public double area() {
			return 0.0;
		}
}