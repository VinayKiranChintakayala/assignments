package wipro.assignments2;
public class Rectangle extends Shape{
	public int length;
	public int breath;
	public Rectangle(int length, int breath) {
		this.breath = breath;
		this.length = length;
	}
	public double area() {
		return length * breath;
	}
}