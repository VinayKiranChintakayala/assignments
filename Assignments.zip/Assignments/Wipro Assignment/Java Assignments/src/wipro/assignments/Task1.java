package wipro.assignments;
import java.util.Scanner;
public class Task1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Declare two integer variables : ");
			int swap1 = scan.nextInt();
			int swap2 = scan.nextInt();
			swap1 = swap1 + swap2;
			swap2 = swap1 - swap2;
			swap1 = swap1 - swap2;
			System.out.printf("The swapped two integer variables are %d and %d",swap1,swap2);
			scan.close();
			}

	}

