package wipro.assignments;
import java.util.Scanner;
public class Task7b {

	    public static int PerformLinearSearch(int[] array, int target) {
	        for (int i = 0; i < array.length; i++) {
	            if (array[i] == target) {
	                return i; 
	            }
	        }
	        return -1;
	    }

	    public static void main(String[] args) {
	       Scanner scan = new Scanner(System.in);
	       System.out.println("Enter the size of the array : ");
	        int size = scan.nextInt();
	        System.out.println("Enter the elements of the array : ");
	        int array[] = new int[size];
	        for(int i =0;i < array.length;i++)
	        	array[i] = scan.nextInt();
	        System.out.println("Enter the specific value to be searched in the array : ");
	        int specificValue = scan.nextInt();
	        int index = PerformLinearSearch(array, specificValue); 
	        if (index != -1) {
	            System.out.println("Element " + specificValue + " found at index: " + index);
	        } else {
	            System.out.println("Element " + specificValue + " not found in the array.");
	        }
	    scan.close();
	    }
}
