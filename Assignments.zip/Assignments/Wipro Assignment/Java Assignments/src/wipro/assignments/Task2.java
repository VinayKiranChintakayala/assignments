package wipro.assignments;
import java.util.Scanner;
public class Task2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter first Number : ");
		int firstNo = scan.nextInt();
		System.out.print("Enter Second Number : ");
		int secondNo = scan.nextInt();
		System.out.printf("Enter the operation to perfrom on %d and %d : ",firstNo,secondNo);
		char symbol = scan.next().charAt(0);
		int result = 0;
		switch(symbol)
		{
		case '+':
			result = firstNo + secondNo;
			System.out.printf("The sum of %d and %d is %d",firstNo,secondNo,result);
			break;
		case '-':
			result = firstNo - secondNo;
			System.out.printf("The subraction of %d and %d is %d",firstNo,secondNo,result);
			break;
		case '*':
			result = firstNo * secondNo;
			System.out.printf("The product of %d and %d is %d",firstNo,secondNo,result);
			break;
		case '/':
			result = firstNo / secondNo;
			System.out.printf("The division of %d and %d is %d",firstNo,secondNo,result);
			break;
		case '%':
			result = firstNo % secondNo;
			System.out.printf("The modulodivison of %d and %d is %d",firstNo,secondNo,result);
			break;
		default:
			System.out.println("Invalid operations");
		}
		scan.close();
	}

}