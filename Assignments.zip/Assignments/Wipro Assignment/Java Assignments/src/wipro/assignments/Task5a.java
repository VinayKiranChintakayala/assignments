package wipro.assignments;
import java.util.Scanner;
public class Task5a 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the number of elements in the array: ");
        int size = scan.nextInt();
        int array[] = new int[size];
        
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) 
        {
            array[i] = scan.nextInt();
        }
        System.out.print("Enter the target sum: ");
        int value = scan.nextInt();
        int result[] = check(array, value);
        if (result == null) 
        {
        	System.out.println("Invalid data");
        } 
        else 
        {
        	System.out.println(result[0] + ", " + result[1]);
        }  
        scan.close();
	}
    public static int[] check(int array[], int value) 
    {
        for (int i = 0; i < array.length; i++) 
        {
            for (int j = i + 1; j < array.length; j++) 
            {
                if (array[i] + array[j] == value) 
                {
                    return new int[] { i, j }; 
                }
            }	
        }
        return null;
    }
}