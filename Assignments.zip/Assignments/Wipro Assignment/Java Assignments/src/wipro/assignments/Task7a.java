package wipro.assignments;
import java.util.Arrays;
import java.util.Scanner;
public class Task7a {
	    public static void bruteForceSort(int[] array) {
	       
	        for (int i = 0; i < array.length - 1; i++) {
	            for (int j = i + 1; j < array.length; j++) {
	                if (array[i] > array[j]) {
	                    int temp = array[i];
	                    array[i] = array[j];
	                    array[j] = temp;
	                }
	            }
	        }
	    }
	    public static void main(String[] args) {
	    	Scanner scan = new Scanner(System.in);
	    	int size = scan.nextInt();
	    	int InitializeArray[] = new int[size];
	    	for(int i = 0;i < InitializeArray.length;i++) {
	    		InitializeArray[i] = scan.nextInt();
	    	}
	        System.out.println("Original Array: " + Arrays.toString(InitializeArray));
	        bruteForceSort(InitializeArray);
	        System.out.println("Sorted Array: " + Arrays.toString(InitializeArray));
	        scan.close();
	}
}
