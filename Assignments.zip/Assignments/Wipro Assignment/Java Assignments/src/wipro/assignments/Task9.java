package wipro.assignments;
import java.util.Scanner;
public class Task9 {
	    public static String subString(String str1, String str2, int length) {
	        String concatenated = str1.concat(str2);
	        String reversed = new StringBuilder(concatenated).reverse().toString();
	        int middleIndex = reversed.length() / 2;
	        int startIndex = middleIndex - length / 2;
	        int endIndex = startIndex + length;
	        if (endIndex > reversed.length()) {
	            return "Substring length exceeds the length of the concatenated string";
	        }
	        String middleSubstring = reversed.substring(startIndex, endIndex);
	        return middleSubstring;
	    }
	    public static void main(String[] args) {
	    	Scanner scan = new Scanner(System.in);
	    	System.out.println("Enter the first string : ");
	    	String str1 = scan.nextLine();
	    	System.out.println("Enter the Second string : ");
	    	String str2 = scan.next();
	    	System.out.println("Enter the length of the string : ");
	    	int length = scan.nextInt();
	        String middleSubstring = subString(str1, str2, length);
	        System.out.println("Middle Substring: " + middleSubstring);
	    scan.close();
	    }
}
