package wipro.assignments;
import java.util.Scanner;
public class Task4 {
	public static void reversefunction(int array[]) {
		int firstElement = 0;
		int lastElement = array.length-1;
		int temp = 0;
		while(firstElement < lastElement) {
			temp = array[firstElement];
			array[firstElement] = array[lastElement];
			array[lastElement] = temp;
		firstElement++;
		lastElement--;
		}
	}	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the array size : ");
		int size = scan.nextInt();
		int array[] = new int[size];
		System.out.println("Read the "+size+" elements for the array : ");
		for(int i = 0; i < size;i++) {
			array[i] = scan.nextInt();
		}
		System.out.println("Array before reverse function : ");
		for(int i=0;i < array.length;i++)
			System.out.print(array[i]+" ");
		reversefunction(array);
		System.out.println("\nArray after reverse function : ");
		for(int i = 0;i<array.length;i++) 
			System.out.print(array[i]+" ");
		scan.close();
	}	
}
