package wipro.assignments;
import java.util.Arrays;
import java.util.Scanner;
public class Task8a {
	    public static int[] sliceArray(int[] array, int start, int end) {
	    		if (start < 0 || start > end || end >= array.length) {
	    				return null; 
	    			}
	    		int size = end - start + 1;
	    		int[] subarray = new int[size];
	    		for (int i = 0; i < size; i++) {
	    			subarray[i] = array[start + i];
	    		}
	    		return subarray;
	    }
	    public static void main(String[] args) {
	    	Scanner scan = new Scanner(System.in);
	    	System.out.println("Enter the size of the array : ");
	        int size = scan.nextInt();
	        System.out.println("Enter the starting element of the array : ");
	        int start = scan.nextInt();
	        System.out.println("Enter the ending element of the array : ");
	        int end = scan.nextInt();
	        System.out.println("Enter the elements into the array : ");
	        int array[] = new int[size];
	        for(int i =0;i < array.length;i++)
	        	array[i] = scan.nextInt();
	        int[] subarray = sliceArray(array, start, end);
	        if (subarray != null) {
	            System.out.println("Original Array: " + Arrays.toString(array));
	            System.out.println("Sliced Array: " + Arrays.toString(subarray));
	        } else {
	            System.out.println("Invalid indices or array.");
	        }
	    scan.close();
	    }
}
