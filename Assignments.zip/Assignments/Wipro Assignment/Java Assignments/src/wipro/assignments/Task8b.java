package wipro.assignments;
import java.util.Scanner;
import java.util.Arrays;
public class Task8b {
	    public static int fibonacci(int n) {
	        if (n <= 1) 
	            return n;
	        return fibonacci(n - 1) + fibonacci(n - 2);
	    }
	    public static int[] functionfibo(int n) {
	        int array[] = new int[n];
	        for (int i = 0; i < n; i++) {
	            array[i] = fibonacci(i);
	        }
	        return array;
	    }
	    public static void main(String[] args) {
	    	Scanner scan = new Scanner(System.in);
	    	int n = scan.nextInt();
	        int[] fiboArray = functionfibo(n);
	        System.out.println("First " + n + " Fibonacci numbers:");
	        System.out.println(Arrays.toString(fiboArray));
	        int nthValue = fibonacci(n - 1);
	        System.out.println("The " + n + "th Fibonacci number is: " + nthValue);
	    scan.close();
	    }
	}

