package wipro.assignments;
import java.util.Scanner;
public class Task6a {
	public static int SumArray(int array[]) {
		int sum=0;
		for(int i = 0; i < array.length; i++) {
			sum+=array[i];
		}
		return sum;
		
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the size of the array : ");
		int size = scan.nextInt();
		System.out.println("Enter the elements into the array : ");
		int array[] = new int[size];
		for(int i =0;i < array.length; i++) {
			array[i] = scan.nextInt();
		}
		System.out.println(SumArray(array));
		scan.close();
	}

}
