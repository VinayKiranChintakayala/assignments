package wipro.assignment3;
import java.util.Scanner;
public class ExceptionHandling {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
	        try {
	            int numerator = scan.nextInt();
	            int denominator = 0;
	            int result = numerator/denominator;
	            System.out.println("Result of division: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("Invalid operation, Exception catch");
	        }
	scan.close();
	}
}
