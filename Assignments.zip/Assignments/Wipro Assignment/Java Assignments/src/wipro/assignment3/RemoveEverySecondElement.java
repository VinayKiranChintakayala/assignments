package wipro.assignment3;
import java.util.ArrayList;
import java.util.List;

public class RemoveEverySecondElement {

    public static void removeEverySecond(List<Integer> list) {
        for (int i = 1; i < list.size(); i += 2) {
            list.remove(i);
        }
    }

    public static void main(String[] args) {
        List<Integer> myList = new ArrayList<>();
        // Populate the list with some elements
        for (int i = 1; i <= 10; i++) {
            myList.add(i);
        }

        System.out.println("Original List: " + myList);
        removeEverySecond(myList);
        System.out.println("List after removing every second element: " + myList);
    }
}

