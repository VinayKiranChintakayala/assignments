package wipro.assignment3;
import java.util.EmptyStackException;
import java.util.Scanner;
public class CustomStack {
    private int[] stack;
    private int top;
    private int capacity;
    public CustomStack(int capacity) {
        this.capacity = capacity;
        stack = new int[capacity];
        top = -1;
    }
    public void push(int element) {
        if (top == capacity - 1) {
            System.out.println("Stack overflow");
            return;
        }
        stack[++top] = element;
    }
    public int pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stack[top--];
    }
    public int peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stack[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the capacity of the stack: ");
        int capacity = scan.nextInt();
        CustomStack stack = new CustomStack(capacity);
        System.out.println("Enter integers to push onto the stack (enter '0' to stop):");
        int input;
        while ((input = scan.nextInt()) != 0) {
            stack.push(input);
        }
        scan.close();
        System.out.println("Popping elements from the stack:");
        while (!stack.isEmpty()) {
            int element = stack.pop();
            System.out.println("Popped: " + element);
        }
    }
}

