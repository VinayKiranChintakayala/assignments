package wipro.assignment3;
import java.util.EmptyStackException;
import java.util.Scanner;
public class CustomQueue<T> {
    private static class Node<T> {
        private T data;
        private Node<T> next;
        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
    private Node<T> front;
    private Node<T> rear;
    public CustomQueue() {
        front = null;
        rear = null;
    }
    public void enqueue(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }
    public T dequeue() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        T data = front.data;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        return data;
    }
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return front.data;
    }
    public boolean isEmpty() {
        return front == null;
    }
    public static void main(String[] args) {
        CustomQueue<String> stringQueue = new CustomQueue<>();
        CustomQueue<Integer> intQueue = new CustomQueue<>();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter strings to enqueue (type 'done' to stop):");
        String inputString;
        while (!(inputString = scan.nextLine()).equalsIgnoreCase("done")) {
            stringQueue.enqueue(inputString);
        }
        System.out.println("Enter integers to enqueue (type '0' to stop):");
        int inputInt;
        while ((inputInt = scan.nextInt()) != 0) {
            intQueue.enqueue(inputInt);
        }
        scan.close();
        System.out.println("Dequeueing strings from the queue:");
        while (!stringQueue.isEmpty()) {
            String str = stringQueue.dequeue();
            System.out.println("Dequeued: " + str);
        }
        System.out.println("\nDequeueing integers from the queue:");
        while (!intQueue.isEmpty()) {
            int num = intQueue.dequeue();
            System.out.println("Dequeued: " + num);
        }
    }
}


