package com.math.operations;

public class Division {
	public static int divide(int a, int b) {
	if (b != 0) {
        return a / b;
    } else {
        throw new ArithmeticException("Division by zero");
		}
	}
}
