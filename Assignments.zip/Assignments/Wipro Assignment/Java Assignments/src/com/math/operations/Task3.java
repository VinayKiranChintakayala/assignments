package com.math.operations;
import java.util.Scanner;
public class Task3 {

	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);	
	int a = scan.nextInt();
	int b = scan.nextInt();
	Addition ad = new Addition();
	System.out.println(ad.add(a, b));
	Subtraction sb = new Subtraction();
	System.out.println(sb.subtract(a, b));
	Multiplication ml = new Multiplication();
	System.out.println(ml.mutilply(a, b));
	Division di = new Division();
	System.out.println(di.divide(a, b));
	ModuloDIvision md = new ModuloDIvision();
	System.out.println(md.modDiv(a, b));
	scan.close();
	}

}
