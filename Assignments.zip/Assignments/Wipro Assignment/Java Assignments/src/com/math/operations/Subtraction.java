package com.math.operations;

public class Subtraction {
	public static int subtract(int a, int b) {
        return a - b;
	}
}
