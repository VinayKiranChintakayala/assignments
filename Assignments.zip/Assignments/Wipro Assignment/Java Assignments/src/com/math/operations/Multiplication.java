package com.math.operations;

public class Multiplication {
	public static int mutilply(int a, int b) {
        return a * b;
	}
}
