package com.math.operations;

public class ModuloDIvision {
	public static int modDiv(int a, int b) {
        return a % b;
	}
}
